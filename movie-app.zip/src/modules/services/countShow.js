const countShow = list => list.length
export default countShow