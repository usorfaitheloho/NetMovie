export const SHOWS_API = 'https://api.tvmaze.com/shows';
export const INVOLVEMENT_API = 'https://us-central1-involvement-api.cloudfunctions.net/capstoneApi/apps';
export const APP_ID = 'UA1qh5oDK24p7rhA1W5m'
export const LIKES = 'likes'
export const COMMENTS = 'comments'