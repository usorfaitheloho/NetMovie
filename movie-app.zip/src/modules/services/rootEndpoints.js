export const SHOWS_API = 'https://api.tvmaze.com/shows';
export const INVOLVEMENT_API = 'https://us-central1-involvement-api.cloudfunctions.net/capstoneApi/apps';
export const APP_ID = 'IONInnzNi3VRPNlFloAi'
export const LIKES = 'likes'
export const COMMENTS = 'comments'