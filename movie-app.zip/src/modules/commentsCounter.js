const commentsCounter = comments => comments.length
export default commentsCounter
